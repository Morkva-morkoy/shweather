notes_file_path = 'notes.txt'
